# Jinn AI Assistant

Run:
pip install -r requirements.txt
uvicorn app:app --reload
