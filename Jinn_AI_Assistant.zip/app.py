from fastapi import FastAPI
from memory.memory import Memory

app = FastAPI(title="Jinn AI Assistant")
memory = Memory()

@app.get("/")
def home():
    return {"assistant":"Jinn","status":"online"}

@app.get("/remember")
def remember(text:str):
    memory.save(text)
    return {"saved":text}
