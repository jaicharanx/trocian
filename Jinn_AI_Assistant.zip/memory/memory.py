import sqlite3

class Memory:
    def __init__(self):
        self.db = sqlite3.connect("memory.db", check_same_thread=False)
        self.db.execute("CREATE TABLE IF NOT EXISTS memories(text TEXT)")

    def save(self, text):
        self.db.execute("INSERT INTO memories VALUES(?)",(text,))
        self.db.commit()
